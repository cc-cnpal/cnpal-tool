#!/bin/bash
# CN-PAL Adoption Tool launcher for macOS (double-click to run).
cd "$(dirname "$0")" || exit 1
case "$(uname -m)" in
  arm64) BIN="./bin/cnpal-tool-arm64" ;;
  *)     BIN="./bin/cnpal-tool-amd64" ;;
esac
# Files received by e-mail/download/zip are quarantined by macOS; clear the
# quarantine flag for this folder so Gatekeeper doesn't block the tool.
xattr -dr com.apple.quarantine . 2>/dev/null
chmod +x "$BIN" 2>/dev/null
clear
echo "Starting the CN-PAL Adoption Tool dashboard..."
echo "Your browser will open automatically. Leave this window open while you use the tool."
echo
"$BIN" "$@"
echo
read -r -p "Press Enter to close this window..." _
