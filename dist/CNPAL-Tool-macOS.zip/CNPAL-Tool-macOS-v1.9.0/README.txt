CN-PAL Adoption Tool for Cisco Catalyst Center — macOS
v1.9.0

STATUS REPORT (updated in v1.9.0)
----------------------------------
"Generate status report" writes a Catalyst Center status report
(Word) with the platform release, device inventory (site assignment,
reachability, manageability, software versions), assurance health,
API activity by area, issues resolved or ignored in the last 30 days
and Catalyst Center sign-ins from the platform's audit log. CSV files
alongside it: api-call-log.csv (every request with timestamp,
endpoint and HTTP status), issues-closed-30d.csv, ui-logins-30d.csv,
devices.csv. A status report is also written automatically when an
Assurance run finishes.


ASSURANCE MODE (v1.6.0+)
-------------------------
The dashboard's "Run Assurance workload" makes about 4,000 read-only
GET calls (Network Health, Client Health, Device/Client 360, Audit
Logs) with a live progress bar, then writes the status report.

READ-ONLY GUARANTEE (v1.6.1+)
------------------------------
Only GET, the login and the Assurance query APIs are sent; anything
that could change Catalyst Center is refused before it is sent.


WHAT THIS IS
------------
A local, read-only assessment tool for Cisco Catalyst Center. It
connects to a Catalyst Center appliance using a read-only account,
gathers inventory, health, lifecycle, security and automation data
through the platform's own REST APIs, scores it against the CN-PAL
(Campus Network Programmability and Integration) adoption criteria,
and produces a Word report you can hand to a customer.

Nothing is changed on the Catalyst Center. Every call the tool makes
only reads data: most are GET requests, and the rest are POST
requests to Catalyst Center's Assurance "query" APIs, which take a
search filter in the request body and return data without changing
anything. Those POST queries are what count as non-GET calls for the
CN-PAL criteria, and they work with a read-only (OBSERVER-ROLE)
account.

Version 1.3.0 replaces the old text-menu with a local web dashboard:
a small program runs on your own Mac, opens a page in your browser,
and everything — connecting, running the assessment, watching
progress, downloading the report — happens through that page. No
data leaves your machine except the API calls to the Catalyst Center
you point it at.


GETTING STARTED
----------------
1. Unzip this folder anywhere on your Mac (Desktop, Downloads, etc.)
2. Double-click "Start.command"
3. The first time you run it, macOS will likely show a security
   prompt — see "THE ONE-TIME SECURITY STEP" below.
4. A terminal window opens briefly and your default browser opens
   automatically to the dashboard (something like
   http://127.0.0.1:54231). Leave the terminal window open in the
   background while you use the tool — closing it stops the tool.
5. In the dashboard, enter the Catalyst Center address, a read-only
   username/password, and the customer name for the report, then
   click Connect. "Prepared by" is optional: if you fill it in (for
   example your company name), it appears on the report cover,
   header and footer; if you leave it blank, the report carries no
   author or company name at all. It is never remembered: the
   field starts empty every time the tool opens. Reports never
   include a logo.
6. Run "Readiness check", "API workload", or "Workload + report".
   Progress and the running log appear live on the page.
7. When the report is ready, click "Download Word report" (and, if
   you want them, the HTML/CSV/JSON files are downloadable too).


THE ONE-TIME SECURITY STEP (Gatekeeper)
-----------------------------------------
This tool is not distributed through the Mac App Store and is not
signed with a paid Apple Developer certificate (that program costs
Apple a yearly fee per publisher, and this build doesn't use one).
Because of that, macOS Gatekeeper may show a warning like
"cnpal-tool-arm64 cannot be opened because the developer cannot be
verified" the first time you run it.

This is expected for any independently-distributed Mac tool that
isn't notarized through Apple, and it is a one-time step:

  Start.command already removes the quarantine flag from the files
  in this folder automatically, so in most cases it will just run.

  If macOS still blocks it:
    1. Open System Settings > Privacy & Security.
    2. Scroll down — you'll see a message naming the blocked file,
       with an "Open Anyway" button next to it. Click it.
    3. Confirm "Open Anyway" again in the dialog that appears.
  You only need to do this once; after that, the tool opens normally.

We know this extra step is not ideal for a customer-facing demo.
The only way to remove it entirely is to distribute the tool through
an Apple Developer ID (paid, annual) and have it notarized by Apple.


THE REPORT
----------
Every generated report is a Word (.docx) document in a neutral navy
and steel-blue color scheme, with a cover page, contents, executive summary,
detailed observations, the assessment calculations behind every
score, findings and recommendations, and appendices.

Throughout the report, every table and figure is preceded by a small
marker showing where it came from:
  - CATALYST CENTER DATA    — retrieved directly from the platform's
                               APIs, unmodified.
  - ASSESSMENT CALCULATION  — a score or metric the tool derived
                               from that data (the inputs and formula
                               are always shown alongside the result).
  - RECOMMENDATION          — guidance written from the observations
                               and calculations above it.

This keeps every statement in the report traceable back to either
the platform itself or an explicit, checkable calculation — nothing
is asserted without showing its source.

Where it matters, the report also names the individual devices behind
a number — not just "19 devices non-compliant" or "22 devices with
end-of-life alerts", but which devices, with the specific category
that failed (running config, image, PSIRT, etc.) and, where Catalyst
Center provides it, the bulletin and end-of-support date. The full
lists are also exported as devices-noncompliant.csv and
devices-eox.csv next to the report.

Reports are saved in your Documents folder under "CNPAL-Reports",
each in its own timestamped subfolder, and are also downloadable directly
from the dashboard.


WEEKLY SCHEDULING & SAVED CREDENTIALS (macOS only)
-----------------------------------------------------
On macOS, the dashboard can save your Catalyst Center password to
the macOS Keychain (instead of retyping it each time) and can
schedule a weekly automatic run via a macOS LaunchAgent. Both are
optional and available from the dashboard once you're connected.


LIMITATIONS
------------
- This is a read-only assessment tool; it does not change any
  Catalyst Center configuration.
- API-call counts shown in the report reflect calls made from this
  workstation over the last 30 days; Catalyst Center's own totals
  may be equal or higher if other integrations also call it.
- Telemetry/on-boarding enablement is not exposed via API and must
  be confirmed manually in Catalyst Center under System > Settings.


SUPPORT
-------
For issues or enhancement requests, contact the person who provided
you with this package.
