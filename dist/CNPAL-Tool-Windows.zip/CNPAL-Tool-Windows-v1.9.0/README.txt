CN-PAL Adoption Tool for Cisco Catalyst Center — Windows
v1.9.0

WHAT THIS IS
------------
A local, read-only assessment tool for Cisco Catalyst Center. It
connects to a Catalyst Center appliance using a read-only account,
gathers inventory, health, lifecycle, security and automation data
through the platform's own REST APIs, scores it against the CN-PAL
(Campus Network Programmability and Integration) adoption criteria,
and produces a Word report you can hand to a customer.

Nothing is changed on the Catalyst Center. Every call the tool makes
only reads data: most are GET requests, and the rest are POST
requests to Catalyst Center's Assurance "query" APIs, which take a
search filter in the request body and return data without changing
anything. Those POST queries are what count as non-GET calls for the
CN-PAL criteria, and they work with a read-only (OBSERVER-ROLE)
account.

Version 1.3.0 replaces the old text-menu with a local web dashboard:
a small program runs on your own PC, opens a page in your browser,
and everything — connecting, running the assessment, watching
progress, downloading the report — happens through that page. No
data leaves your machine except the API calls to the Catalyst Center
you point it at.


GETTING STARTED
----------------
1. Unzip this folder anywhere on your PC (Desktop, Downloads, etc.)
   Right-click the .zip and choose "Extract All..." — don't run the
   files directly from inside the zip viewer.
2. Double-click "Start.bat"
3. The first time you run it, Windows may show a SmartScreen
   warning — see "READ-ONLY GUARANTEE (v1.6.1)
-----------------------------
The tool cannot change anything on Catalyst Center, even if you
connect with a read-write or admin account. Before any request is
sent, the tool checks it: only GET requests, the login, and 14
Assurance "query" requests (which only return data) are allowed.
Anything else (PUT, PATCH, DELETE or any other POST) is refused on
this computer and never sent. A read-only (OBSERVER-ROLE) account is
still recommended.


STATUS REPORT (updated in v1.9.0)
----------------------------------
"Generate status report" writes a Catalyst Center status report
(Word) with the platform release, device inventory (site assignment,
reachability, manageability, software versions), assurance health,
API activity by area, issues resolved or ignored in the last 30 days
and Catalyst Center sign-ins from the platform's audit log. CSV files
alongside it: api-call-log.csv (every request with timestamp,
endpoint and HTTP status), issues-closed-30d.csv, ui-logins-30d.csv,
devices.csv. A status report is also written automatically when an
Assurance run finishes.


ASSURANCE MODE (new in v1.6.0)
-------------------------------
For the Catalyst Center Assurance LCI use case ("Monitor and
troubleshoot your network"), the dashboard has an "Assurance use
case" card. Click "Run Assurance workload". It makes about 4,000
read-only GET calls over roughly one hour and covers the API-call
targets of the Engage and Adopt stages for:

  Task 4  Monitor Network Health   (Adopt: 600 calls)
  Task 5  Monitor Client Health    (Adopt: 600 calls)
  Task 6  Device / Client 360      (Adopt: 2,000 calls)
  Task 7  Analyze & Troubleshoot   (Adopt: 500 Audit Log calls)

While it runs, the card shows a live progress bar with the API
calls done, pending and total, the time elapsed, the time remaining
and the estimated finish time. The estimate follows the current
speed, so it can change when a slower group starts.

Keep the command window open and the laptop awake (plugged in, sleep
off) until the log says "Assurance workload finished". The table on
the card shows each task's 30-day count against the targets.
Running it again later only tops up what is missing.

Task 8 (resolve 10 issues for Engage, 100 for Adopt) cannot be done
with a read-only account. Do it in Catalyst Center: Assurance >
Issues > select the issues > Resolve.

Cisco's LCI portal reads these counts through telemetry, so the
portal can take a day or two to show the tasks as complete.


THE ONE-TIME SECURITY STEP" below.
4. A command window opens briefly and your default browser opens
   automatically to the dashboard (something like
   http://127.0.0.1:54231). Leave the command window open in the
   background while you use the tool — closing it stops the tool.
5. In the dashboard, enter the Catalyst Center address, a read-only
   username/password, and the customer name for the report, then
   click Connect. "Prepared by" is optional: if you fill it in (for
   example your company name), it appears on the report cover,
   header and footer; if you leave it blank, the report carries no
   author or company name at all. It is never remembered: the
   field starts empty every time the tool opens. Reports never
   include a logo.
6. Run "Readiness check", "API workload", or "Workload + report".
   Progress and the running log appear live on the page.
7. When the report is ready, click "Download Word report" (and, if
   you want them, the HTML/CSV/JSON files are downloadable too).


THE ONE-TIME SECURITY STEP (SmartScreen)
-------------------------------------------
This tool is not distributed through the Microsoft Store and its
executables are not signed with a paid code-signing certificate
(commercial certificates cost several hundred dollars a year and
this build doesn't use one). Because of that, Windows SmartScreen
may show "Windows protected your PC" the first time you run it.

This is expected for any independently-distributed Windows tool that
isn't code-signed, and it is a one-time step:

  Start.bat already runs Unblock-File on every file in this folder
  automatically, which removes the "downloaded from the internet"
  marker that most commonly triggers SmartScreen — in many cases
  this means it will just run.

  If Windows still shows the blue "Windows protected your PC" screen:
    1. Click "More info".
    2. Click "Run anyway".
  You only need to do this once per file; after that, Windows
  remembers your choice for these executables.

We know this extra step is not ideal for a customer-facing demo.
The only way to remove it entirely is to sign the executables with a
commercial code-signing certificate (paid, annual) tied to your
organization as the publisher.


THE REPORT
----------
Every generated report is a Word (.docx) document in a neutral navy
and steel-blue color scheme, with a cover page, contents, executive summary,
detailed observations, the assessment calculations behind every
score, findings and recommendations, and appendices.

Throughout the report, every table and figure is preceded by a small
marker showing where it came from:
  - CATALYST CENTER DATA    — retrieved directly from the platform's
                               APIs, unmodified.
  - ASSESSMENT CALCULATION  — a score or metric the tool derived
                               from that data (the inputs and formula
                               are always shown alongside the result).
  - RECOMMENDATION          — guidance written from the observations
                               and calculations above it.

This keeps every statement in the report traceable back to either
the platform itself or an explicit, checkable calculation — nothing
is asserted without showing its source.

Where it matters, the report also names the individual devices behind
a number — not just "19 devices non-compliant" or "22 devices with
end-of-life alerts", but which devices, with the specific category
that failed (running config, image, PSIRT, etc.) and, where Catalyst
Center provides it, the bulletin and end-of-support date. The full
lists are also exported as devices-noncompliant.csv and
devices-eox.csv next to the report.

Reports are saved in your Documents folder under "CNPAL-Reports",
each in its own timestamped subfolder, and are also downloadable directly
from the dashboard.


KNOWN LIMITATION: SAVED CREDENTIALS & SCHEDULING
----------------------------------------------------
On macOS, this tool can save your Catalyst Center password to the
system Keychain and schedule a weekly automatic run. Those two
conveniences are not yet implemented on Windows — on this platform,
you enter the password each time you connect, and there is no
built-in weekly scheduler in the dashboard. Everything else (running
checks, generating and downloading the report) works identically on
both platforms. If weekly scheduling on Windows would be useful, it
can be added using Windows Credential Manager and Task Scheduler —
let us know if you'd like that built out.


LIMITATIONS
------------
- This is a read-only assessment tool; it does not change any
  Catalyst Center configuration.
- API-call counts shown in the report reflect calls made from this
  workstation over the last 30 days; Catalyst Center's own totals
  may be equal or higher if other integrations also call it.
- Telemetry/on-boarding enablement is not exposed via API and must
  be confirmed manually in Catalyst Center under System > Settings.


SUPPORT
-------
For issues or enhancement requests, contact the person who provided
you with this package.
