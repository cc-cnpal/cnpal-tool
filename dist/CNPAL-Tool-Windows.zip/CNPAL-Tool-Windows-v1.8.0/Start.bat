@echo off
setlocal
cd /d "%~dp0"

echo Preparing the CN-PAL Adoption Tool...

rem Windows marks every file extracted from a downloaded zip as coming
rem from the internet (Mark-of-the-Web), which is what triggers a
rem SmartScreen warning. Unblock-File removes that marker from every
rem file in this folder so the tool can start without the prompt in
rem most cases.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path '%~dp0' -Recurse | Unblock-File" >nul 2>&1

set ARCH=amd64
if /I "%PROCESSOR_ARCHITECTURE%"=="ARM64" set ARCH=arm64
if defined PROCESSOR_ARCHITEW6432 if /I "%PROCESSOR_ARCHITEW6432%"=="ARM64" set ARCH=arm64

set BIN=bin\cnpal-tool-%ARCH%.exe
if not exist "%BIN%" set BIN=bin\cnpal-tool-amd64.exe

echo Starting the dashboard...
echo Your browser will open automatically. Leave this window open while you use the tool.
echo.
"%BIN%"

echo.
pause
